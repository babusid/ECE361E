p#_q#.py (6 files total) -- code for each question/part requiring code
results_and_discussions.pdf -- results and discussions, including tables and graphs
readme.txt -- text file explaining file contents of submission zip file
